FspWinTaskbar - Windows7 Taskbar Components
(c) FSPro Labs, 2010-2011
http://delphi.fsprolabs.com
License: see license.txt



Overview
--------
This component set is designed to develop application that supports new feature of Windows 7 task bar.

It�s compatible with  Delphi 5,6,7,2006,2007,2009,2010,XE,XE2.
Most probably, it will work with BCB.
Note: I tested it only with Delphi 5, Delphi 7, Delphi 2010, Delphi XE and Delphi XE2!!!

Components
----------
TfspTaskbarMgr � sets button overlay icon and progress bar and allows you to set your own Application ID
(different AppIDs for each instance of the same application prevent Windows from joining all these 
instances in one application button on the taskbar).

TfspTaskbarPreviews lets you to create own icon preview for you application.

TfspTaskbarTabMgr creates tabs on taskbar button like Internet Explorer does.


Installation
------------

Delphi5:

Install design-time package dclfspWinTaskbar_D5.dpk

Delphi 7-XE2

Install design-time package dclfspWinTaskbar_DX.dpk

Sorry, no idea about Delphi 6.

If something goes wrong with installation, you may try to install 
fspWinTaskbarReg.pas to a New Package (use Component->Install Component)

Comments
--------
If you have Delphi 2007 or higher, it�s recommended to use
    Application.MainFormOnTaskBar := True in the dpr file (see "TaskBarMgr&Previews" example)

We use  CoInitializeEx(nil, COINIT_APARTMENTTHREADED ) in one of our units;
In some cases, your main thread may require multi-threaded object concurrency (COINIT_MULTITHREADED). 
If so, define FSP_COINIT_MULTITHREADED in the Project defines.

Some win controls may paint themself incorrectly on previews.
In this case try to add the class name into one of fspPatch_xxxxx lists.
See initialization of fspControlsExt.pas unit for reference.


Credits
-------
Valerian Kadyshev (www.superutils.com)  - valuable contribution to fspTaskbarMgr.pas
Daniel Gaussmann - suggested to change default bitmap stretchmode for fspControl2DIBPreview.



Feedback
--------
Send feedbacks to delphi@fsprolabs.com