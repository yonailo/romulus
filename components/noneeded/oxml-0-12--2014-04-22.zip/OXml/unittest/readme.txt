OXml UNIT TESTING
=================

I will add unit tests here for bugs in OXml.

All languages (Delphi 2009+, Delphi 2007-, Lazarus/FPC) share the same unit tests.

To be absolutely correct, there are not only "unit tests" here but all kinds of tests (integration etc.).