OXml DEMOS
==========

Delphi 2009+ VCL / Delphi 6-2007 VCL / Lazarus
----------------------------------------------
  - big demo application for non-unicode & unicode Delphi and Lazarus.
  - introduces showcases how to use every OXml parser/writer.
  - introduces some performance tests.
  - License: public domain



ErrorInfo
---------
  - a demo with XML errors converted from OmniXML.
  - License: MPL 1.1
  - Original developer: Miha Remec, http://www.omnixml.com




FileList
--------
  - a "real world" demo converted from OmniXML.
  - showcase how to use:
    - TOXmlWriter (unit OXmlReadWrite)
    - IXMLDocument (unit OXmlPDOM)
    - TXMLSeqParser (unit OXmlSeq)
  - License: MPL 1.1
  - Original developer: Miha Remec, http://www.omnixml.com



XPath
-----
  - some XPath examples converted from OmniXML.
  - License: MPL 1.1
  - Original developer: Miha Remec, http://www.omnixml.com
